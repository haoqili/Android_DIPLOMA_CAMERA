373 seems weird. These two phones were not stacked on top of each other. So I don't think they were used for the last (final) experiment of 5 stationary leaders
